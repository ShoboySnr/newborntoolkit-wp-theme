/**
 * Internal dependencies
 */

import './blocks/container';
